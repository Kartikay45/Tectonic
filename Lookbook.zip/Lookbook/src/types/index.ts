export interface Product {
    id: string;
    name: string;
    price: number;
    description: string;
    imageUrl: string;
}

export interface Annotation {
    x: number;
    y: number;
    product: Product;
}

export interface MediaItem {
    type: 'image' | 'video';
    url: string;
    annotations?: Annotation[];
    duration?: number; // for videos
}

export interface Look {
    id: string;
    title: string;
    author: {
        name: string;
        isVerified: boolean;
        avatarUrl: string;
    };
    media: MediaItem[];
    products: Product[];
} 