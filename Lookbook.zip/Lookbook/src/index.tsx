import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './styles/main.scss';

const root = document.getElementById('root');

if (!root) {
    throw new Error('Root element not found');
}

const rootElement = ReactDOM.createRoot(root);

rootElement.render(
    <React.StrictMode>
        <App />
    </React.StrictMode>
); 