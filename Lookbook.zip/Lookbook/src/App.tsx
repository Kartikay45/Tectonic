import React from 'react';
import FashionLookbook from './components/FashionLookbook';
import './styles/main.scss';

const App: React.FC = () => (
    <div className="App">
        <FashionLookbook />
    </div>
);

export default App; 