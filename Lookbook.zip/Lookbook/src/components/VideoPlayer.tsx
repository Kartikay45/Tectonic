import React, { useRef, useEffect } from 'react';

interface VideoPlayerProps {
    url: string;
    isPlaying: boolean;
    onComplete: () => void;
}

const VideoPlayer: React.FC<VideoPlayerProps> = ({ url, isPlaying, onComplete }) => {
    const videoRef = useRef<HTMLVideoElement>(null);

    useEffect(() => {
        if (videoRef.current) {
            if (isPlaying) {
                videoRef.current.play();
            } else {
                videoRef.current.pause();
            }
        }
    }, [isPlaying]);

    return (
        <video
            ref={videoRef}
            src={url}
            className="video-player"
            onEnded={onComplete}
            playsInline
            controls
        />
    );
};

export default VideoPlayer; 