import React from 'react';
import { Product } from '../types';

interface ProductModalProps {
    product: Product;
    onClose: () => void;
}

const ProductModal: React.FC<ProductModalProps> = ({ product, onClose }) => {
    return (
        <div className="product-modal">
            <div className="product-modal__content">
                <button className="product-modal__close" onClick={onClose}>×</button>
                <img src={product.imageUrl} alt={product.name} />
                <h2>{product.name}</h2>
                <p className="product-modal__price">${product.price}</p>
                <p className="product-modal__description">{product.description}</p>
                <button className="product-modal__shop-button">Shop Now</button>
            </div>
        </div>
    );
};

export default ProductModal;