import React, { useState, useEffect } from 'react';
import { Swiper, SwiperSlide } from 'swiper/react';
import MediaAnnotation from './MediaAnnotation';
import ProgressBar from './ProgressBar';
import { Look, MediaItem } from '../types';
import '../styles/components/LookPreview.scss';

interface LookPreviewProps {
    look: Look;
}

const LookPreview: React.FC<LookPreviewProps> = ({ look }) => {
    const [currentMediaIndex, setCurrentMediaIndex] = useState(0);
    const [isPlaying, setIsPlaying] = useState(true);

    const handleMediaComplete = () => {
        if (currentMediaIndex < look.media.length - 1) {
            setCurrentMediaIndex(prev => prev + 1);
        }
    };

    return (
        <div className="look-preview">
            <div className="look-preview__header">
                <img 
                    src={look.author.avatarUrl} 
                    alt={look.author.name} 
                    className="look-preview__author-avatar"
                />
                <span className="look-preview__author-name">
                    {look.author.name}
                    {look.author.isVerified && <span className="verified-badge">✓</span>}
                </span>
            </div>

            <Swiper
                onSlideChange={(swiper) => setCurrentMediaIndex(swiper.activeIndex)}
                className="look-preview__media-swiper"
            >
                {look.media.map((media, index) => (
                    <SwiperSlide key={index}>
                        <MediaAnnotation 
                            media={media}
                            isPlaying={isPlaying && currentMediaIndex === index}
                            onComplete={handleMediaComplete}
                        />
                        {media.type === 'image' && (
                            <ProgressBar 
                                duration={5000}
                                isPlaying={isPlaying && currentMediaIndex === index}
                                onComplete={handleMediaComplete}
                            />
                        )}
                    </SwiperSlide>
                ))}
            </Swiper>
        </div>
    );
};

export default LookPreview; 