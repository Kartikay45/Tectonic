import React, { useState } from 'react';
import VideoPlayer from './VideoPlayer';
import ProductModal from './ProductModal';
import { MediaItem, Product } from '../types';
import '../styles/components/MediaAnnotation.scss';

interface MediaAnnotationProps {
    media: MediaItem;
    isPlaying: boolean;
    onComplete: () => void;
}

const MediaAnnotation: React.FC<MediaAnnotationProps> = ({ media, isPlaying, onComplete }) => {
    const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

    return (
        <div className="media-annotation">
            {media.type === 'image' ? (
                <div className="media-annotation__image-container">
                    <img src={media.url} alt="Look" />
                    {media.annotations?.map((annotation, index) => (
                        <button
                            key={index}
                            className="annotation-dot"
                            style={{ left: `${annotation.x}%`, top: `${annotation.y}%` }}
                            onClick={() => setSelectedProduct(annotation.product)}
                        />
                    ))}
                </div>
            ) : (
                <VideoPlayer
                    url={media.url}
                    isPlaying={isPlaying}
                    onComplete={onComplete}
                />
            )}

            {selectedProduct && (
                <ProductModal
                    product={selectedProduct}
                    onClose={() => setSelectedProduct(null)}
                />
            )}
        </div>
    );
};

export default MediaAnnotation; 