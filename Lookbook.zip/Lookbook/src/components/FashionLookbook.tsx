import React, { useState } from 'react';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Navigation, Pagination } from 'swiper/modules';
import LookPreview from './LookPreview';
import { Look } from '../types';
import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/pagination';
import '../styles/components/FashionLookbook.scss';

const FashionLookbook: React.FC = () => {
    const [currentLook, setCurrentLook] = useState<number>(0);
    const [looks] = useState<Look[]>([]); // Replace with actual data or API call

    return (
        <div className="lookbook-container">
            <Swiper
                direction="vertical"
                modules={[Navigation, Pagination]}
                navigation
                pagination={{ clickable: true }}
                onSlideChange={(swiper) => setCurrentLook(swiper.activeIndex)}
            >
                {looks.map((look) => (
                    <SwiperSlide key={look.id}>
                        <LookPreview look={look} />
                    </SwiperSlide>
                ))}
            </Swiper>
        </div>
    );
};

export default FashionLookbook;