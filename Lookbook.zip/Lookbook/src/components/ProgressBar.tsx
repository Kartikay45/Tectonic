import React, { useEffect, useState } from 'react';

interface ProgressBarProps {
    duration: number;
    isPlaying: boolean;
    onComplete: () => void;
}

const ProgressBar: React.FC<ProgressBarProps> = ({ duration, isPlaying, onComplete }) => {
    const [progress, setProgress] = useState(0);

    useEffect(() => {
        let intervalId: NodeJS.Timeout;

        if (isPlaying) {
            const startTime = Date.now() - (progress * duration);
            
            intervalId = setInterval(() => {
                const elapsed = Date.now() - startTime;
                const newProgress = Math.min(elapsed / duration, 1);
                setProgress(newProgress);

                if (newProgress >= 1) {
                    onComplete();
                    clearInterval(intervalId);
                }
            }, 16);
        }

        return () => {
            if (intervalId) {
                clearInterval(intervalId);
            }
        };
    }, [isPlaying, duration, onComplete, progress]);

    return (
        <div className="progress-bar">
            <div 
                className="progress-bar__fill" 
                style={{ width: `${progress * 100}%` }}
            />
        </div>
    );
};

export default ProgressBar; 